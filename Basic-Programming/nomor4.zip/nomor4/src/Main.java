import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        System.out.println("Input: ");
        int nomor=input.nextInt();
        System.out.println("Output: ");
        System.out.println(nomorprima(nomor));

    }
    private static boolean nomorprima(int number) {
        int i, count=0;

        for (i=1; i<= number; i++){
            if (number % i == 0){
                count=0;
            }
        }
        if (count == 2){
            return true;
        }
        else {
            return false;
        }

    }
}