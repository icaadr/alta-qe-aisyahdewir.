import java.util.Scanner;
public class Main3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Input:");
        int a = input.nextInt();
        System.out.println("Output: ");
        int b = 0;
        for (int z = 0; z <= a; z++) {
            b++;
            if (a % b == 0) {
                System.out.println(b);
            }
        }
    }
}