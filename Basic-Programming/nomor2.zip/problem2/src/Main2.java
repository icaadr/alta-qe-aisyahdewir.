import java.util.Scanner;
public class Main2 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("Masukkan nilai siswa=");
        int a = input.nextInt();
        if (80<=a && a<=100){
            System.out.println("Nilai Siswa = A");
        }
        else if (65<=a && a<=79){
            System.out.println("Nilai Siswa = B+");
        }
        else if (50<=a && a<=64){
            System.out.println("Nilai Siswa = B");
        }
        else if (35<=a && a<=49){
            System.out.println("Nilai Siswa = C");
        }
        else {
            System.out.println("Nilai Siswa = D");
        }

    }
}
