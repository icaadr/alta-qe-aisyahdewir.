import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        String word,inreturn = "";
        Scanner input = new Scanner(System.in);
        System.out.print("Input text= ");
        word = input.nextLine();

        palindrome(word, inreturn);
    }
    private static void palindrome(String word, String inreturn){
        int length = word.length();

        for (int i=word.length()-1; i>=0; i--){
            inreturn = inreturn+ word.charAt(i);
        }
        if (word.equals(inreturn)){
            System.out.println("Text adalah poliandrome");
        }
        else{
            System.out.println("Text bukan poliandrome");
        }
    }
}
