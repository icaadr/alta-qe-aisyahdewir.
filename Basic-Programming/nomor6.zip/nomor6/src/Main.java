import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input: ");
        int number = input.nextInt();
        int index = 1;

        for (int row = 1; row <= number ; row++) {
            if (number % 2 == 0) {
                System.out.print("Z");
            } else if (number % 3 == 0) {
                System.out.print("X");
            } else {
                System.out.print("Y");
            }
            for (int coulumn = 1; coulumn <= number; coulumn++) {
                if (number % 2 == 0) {
                    System.out.println("Z");
                } else if (number % 3 == 0) {
                    System.out.println("X");
                } else {
                    System.out.println("Y");
                }
            }
        }
    }
}