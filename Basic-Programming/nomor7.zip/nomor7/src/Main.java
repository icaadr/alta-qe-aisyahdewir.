import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Input value 1: ");
        float value1 = input.nextFloat();
        System.out.print("Input value 2: ");
        float value2 = input.nextFloat();
        System.out.print("Input value 3: ");
        float value3 = input.nextFloat();
        System.out.print("Input value 4: ");
        float value4 = input.nextFloat();
        System.out.print("Nilai mean= " +nilaimean(value1, value2,value3,value4));
        }
    private static float nilaimean (float value1, float value2,float value3,float value4) {
        float mean = (value1*value2*value3*value4)/4;
        return mean;

    }
}