public class kubus {
    String Tipebangunruang1;
    int panjangkubus;

    public kubus(String Tipebangunruang1, int panjangkubus) {
        this.Tipebangunruang1 = Tipebangunruang1;
        this.panjangkubus = panjangkubus;

    }

    public int luaskubus() {
        return (panjangkubus * panjangkubus*panjangkubus);
    }
}
