public class tabung {
    String Tiperuang3;
    double jarijaritabung;
    double tinggitabung;

    public tabung(String Tiperuang3, double jarijaritabung, double tinggitabung){
        this.Tiperuang3 = Tiperuang3;
        this.jarijaritabung = jarijaritabung;
        this.tinggitabung = tinggitabung;
    }

    public double volumetabung(){
        return(3.14*jarijaritabung*jarijaritabung*tinggitabung);
    }
}

