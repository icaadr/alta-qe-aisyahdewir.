public class balok {
    String Tipebangunruang2;
    int panjangbalok;
    int lebarbalok;
    int tinggibalok;

    public balok(String Tipebangunruang2, int panjangbalok, int lebarbalok, int tinggibalok){
        this.Tipebangunruang2 = Tipebangunruang2;
        this.panjangbalok = panjangbalok;
        this.lebarbalok = lebarbalok;
        this.tinggibalok = tinggibalok;
    }
    public int luasbalok(){
        return (panjangbalok*lebarbalok*tinggibalok);
    }

}
