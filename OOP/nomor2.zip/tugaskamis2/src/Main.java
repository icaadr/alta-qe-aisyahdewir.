import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Menghitung Volume Bangun Ruang");
        System.out.println("Input variabel - variabel Kubus:");
        System.out.println("panjang = ");
        int panjangkubus = input.nextInt();
        String Tipebangunruang1 = input.nextLine();
        kubus volumekubus = new kubus( Tipebangunruang1, panjangkubus);
        System.out.println(Tipebangunruang1 + "mempunyai volume= " + volumekubus.luaskubus());

        System.out.println("");
        System.out.println("Menghitung Volume Bangun Ruang");
        System.out.println("Input variabel - variabel Balok:");
        System.out.println("panjang = ");
        int panjangbalok = input.nextInt();
        System.out.println("lebar = ");
        int lebarbalok = input.nextInt();
        System.out.println("tinggi = ");
        int tinggibalok = input.nextInt();
        String Tipebangunruang2 = input.nextLine();
        balok volumebalok = new balok(Tipebangunruang2, panjangbalok, lebarbalok, tinggibalok);
        System.out.println(Tipebangunruang2 + "mempunyai volume= " + volumekubus.luaskubus());

        System.out.println("");
        System.out.println("Menghitung Volume Bangun Ruang");
        System.out.println("Input variabel - variabel Tabung:");
        System.out.println("jari - jari = ");
        int jarijaritabung = input.nextInt();
        System.out.println("tinggi = ");
        int tinggitabung = input.nextInt();
        String Tipebangunruang3 = input.nextLine();
        tabung volumetabung = new tabung(Tipebangunruang3, jarijaritabung, tinggitabung);
        System.out.println(Tipebangunruang3 + "mempunyai volume= " + volumekubus.luaskubus());



    }
}