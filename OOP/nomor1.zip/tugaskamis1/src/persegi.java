public class persegi {
    String Tipebangundatar;
    int panjang;
    public persegi(String Tipebangundatar, int panjang){
        this.panjang = panjang;
    }
    public int luaspersegi(){
        return (this.panjang*this.panjang);
    }
    public int kelilingpersegi(){
        return (this.panjang*4) ;
    }
}
