public class segitiga {
    String bangundatarsegitiga;
    double alas;
    double tinggi;
    public segitiga (String bangundatarsegitiga, double alas, double tinggi){
        this.bangundatarsegitiga=bangundatarsegitiga;
        this.alas=alas;
        this.tinggi=tinggi;
    }
    public double luassegitiga(){
        return(0.5*alas*tinggi);
    }
    public double kelilingsegitiga(){
        return(alas*3);
    }
}
