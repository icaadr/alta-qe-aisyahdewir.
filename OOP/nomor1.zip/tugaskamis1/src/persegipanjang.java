public class persegipanjang {
    String Tipebangundatar2;
    int panjang2;
    int lebar;

    public persegipanjang( String Tipebangundatar2, int panjang2, int lebar){
        this.panjang2 = panjang2;
        this.lebar = lebar;
    }
    public int luaspersegipanjang(){
        return(panjang2*lebar);
    }
    public int kelilingpersegipanjang(){
        return((panjang2*2)+(lebar*2));
    }
}
