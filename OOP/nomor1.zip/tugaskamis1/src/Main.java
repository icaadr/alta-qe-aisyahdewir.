import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Menghitung Luas dan Keliling Persegi");
        System.out.println("Input tipe bangun datar:");
        String Tipebangundatar = input.nextLine();
        System.out.println("Input panjang untuk persegi=");
        int panjang = input.nextInt();
        persegi persegi1 = new persegi(Tipebangundatar, panjang);
        System.out.println(Tipebangundatar + " mempunyai hasil luas= " + persegi1.luaspersegi());
        System.out.println(Tipebangundatar + " mempunyai hasil keliling= " + persegi1.kelilingpersegi());

        System.out.println("");
        System.out.println("Menghitung Luas dan Keliling Persegi Panjang");
        System.out.println("Input tipe bangun datar:");
        String Tipebangundatar21 = input.nextLine();
        String Tipebangundatar2 = input.nextLine();
        System.out.println("Input panjang untuk Persegi Panjang=");
        int panjang2 = input.nextInt();
        System.out.println("Input lebar untuk Persegi Panjang=");
        int lebar = input.nextInt();
        persegipanjang persegi2 = new persegipanjang(Tipebangundatar2, panjang2, lebar);
        System.out.println(Tipebangundatar21 +"Persegi Panjang mempunyai hasil luas= " + persegi2.luaspersegipanjang());
        System.out.println(Tipebangundatar21 +"Persegi Panjang mempunyai hasil keliling= " + persegi2.kelilingpersegipanjang());


        System.out.println("");
        System.out.println("Menghitung Luas dan Keliling Segitiga sama sisi");
        System.out.println("Input tipe bangun datar");
        String bangundatarsegitiga2 = input.nextLine();
        String bangundatarsegitiga = input.nextLine();
        System.out.println("Input alas untuk segitiga=");
        double alas = input.nextDouble();
        System.out.println("Input tinggi untuk segitiga=");
        double tinggi = input.nextDouble();
        segitiga segitiga = new segitiga(bangundatarsegitiga, alas, tinggi);
        System.out.println(bangundatarsegitiga2+ "Segitiga sama sisi mempunyai hasil luas= " + segitiga.luassegitiga());
        System.out.println(bangundatarsegitiga2+"Segitiga sama sisi mempunyai hasil keliling= " + segitiga.kelilingsegitiga());




    }
}