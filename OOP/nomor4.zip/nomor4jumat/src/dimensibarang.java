public class dimensibarang {
    int panjang;
    int lebar;
    int tinggi;

    double dimensi;
    double berat;
    double ongkoskirimdimensi;
    double ongkoskirimberat;

    public int getPanjang() {
        return panjang;
    }

    public void setPanjang(int panjang) {
        this.panjang = panjang;
    }

    public int getLebar() {
        return lebar;
    }

    public void setLebar(int lebar) {
        this.lebar = lebar;
    }

    public int getTinggi() {
        return tinggi;
    }

    public void setTinggi(int tinggi) {
        this.tinggi = tinggi;
    }

    public double getDimensi() {
        return dimensi;
    }

    public void setDimensi(double dimensi) {
        this.dimensi = dimensi;
    }

    public double getBerat() {
        return berat;
    }

    public void setBerat(double berat) {
        this.berat = berat;
    }

    public double getOngkoskirimdimensi() {
        return ongkoskirimdimensi;
    }

    public void setOngkoskirimdimensi(double ongkoskirimdimensi) {
        this.ongkoskirimdimensi = ongkoskirimdimensi;
    }

    public double getOngkoskirimberat() {
        return ongkoskirimberat;
    }

    public void setOngkoskirimberat(double ongkoskirimberat) {
        this.ongkoskirimberat = ongkoskirimberat;
    }
}