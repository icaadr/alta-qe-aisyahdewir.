public class hargaongkir extends dimensibarang{
    public int totalongkoskirim(){
        int o = 5000;
        double baseDimensi = 50.0;
        double baseBerat = 1.0;


        if (dimensi <= 50 || berat <= 1){
            System.out.println("Harga minimum ongkos kirim= " + o);

        }
        if  (dimensi > 50 || berat > 1 ){
            if (dimensi > 50){
                double roundDimensi= (double)Math.ceil(dimensi/baseDimensi);
                ongkoskirimdimensi = (double) (roundDimensi *5000);
            }
            if (berat >1){
                double roundBerat = Math.ceil(berat/baseBerat);
                ongkoskirimberat = (double)(roundBerat *5000);
            }
            if (ongkoskirimdimensi > ongkoskirimberat){
                o = (int) ongkoskirimdimensi;
            }else{
                o = (int) ongkoskirimberat;
            }
            return o;
        }
        return o;
    }

}
