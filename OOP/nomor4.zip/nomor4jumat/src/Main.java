import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Menghitung Harga Ongkir");
        System.out.println("Input panjang:");
        int panjang = input.nextInt();
        System.out.println("Input lebar:");
        int lebar = input.nextInt();
        System.out.println("Input tinggi:");
        int tinggi = input.nextInt();
        System.out.println("Input berat:");
        double berat = input.nextDouble();
        hargaongkir hasil = new hargaongkir();
        hasil.setPanjang(panjang);
        hasil.setLebar(lebar);
        hasil.setTinggi(tinggi);
        hasil.setBerat(berat);
        System.out.println("Total Harga Ongkos Kirim= " + hasil.totalongkoskirim());

    }
}