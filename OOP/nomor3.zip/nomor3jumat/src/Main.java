import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Kalkulator Sederhana");
        System.out.println("");
        System.out.println("Kalkulator Penjumlahan");
        System.out.println("input angka pertama=");
        int a = input.nextInt();
        System.out.println("input angka kedua=");
        int b = input.nextInt();
        kalkulator perhitungan = new kalkulator();
        perhitungan.setA(a);
        perhitungan.setB(b);
        System.out.println("hasil jumlah= " + perhitungan.hasilpenjumlahan());


        System.out.println("");
        System.out.println("Kalkulator Pengurangan");
        System.out.println("input angka pertama=");
        int a2 = input.nextInt();
        System.out.println("input angka kedua=");
        int b2 = input.nextInt();
        kalkulator perhitungan2 = new kalkulator();
        perhitungan2.setA(a2);
        perhitungan2.setB(b2);
        System.out.println("hasil kurang= " + perhitungan2.hasilpengurangan());


        System.out.println("");
        System.out.println("Kalkulator Perkalian");
        System.out.println("input angka pertama=");
        int a3 = input.nextInt();
        System.out.println("input angka kedua=");
        int b3 = input.nextInt();
        kalkulator perhitungan3 = new kalkulator();
        perhitungan3.setA(a3);
        perhitungan3.setB(b3);
        System.out.println("hasil kali= " + perhitungan3.hasilperkalian());

        System.out.println("");
        System.out.println("Kalkulator Pembagian");
        System.out.println("Input angka pertama=");
        int a4 = input.nextInt();
        System.out.println("Input angka kedua=");
        int b4 = input.nextInt();
        kalkulator perhitungan4 = new kalkulator();
        perhitungan4.setA(a4);
        perhitungan4.setB(b4);
        System.out.println("hasil kali= " + perhitungan4.hasilpembagian());


    }
}