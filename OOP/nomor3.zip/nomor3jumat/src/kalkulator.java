public class kalkulator extends inputangka {


    public int hasilpenjumlahan(){
        return(this.a+this.b);
    }
    public int hasilpengurangan(){
        return(this.a-this.b);
    }
    public int hasilperkalian(){
        return(this.a*this.b);
    }
    public int hasilpembagian(){
        return(this.a/this.b);
    }


}
